A Pen created at CodePen.io. You can find this one at https://codepen.io/enesser/pen/jdenE.

 Started from an example from Packt publishing and changed the perspective to create a really neat effect.