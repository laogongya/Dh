<div id="footer"><a href="http://www.noome.cn" target="_blank" style="color:#999999">Copyright © 2018-2020版权所有</span>
			<br/></a>
</div> 