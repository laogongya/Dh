<title>VIP视解析管理后台</title>
<meta name="keywords" content="VIP影视解析平台" />
<meta name="description" content="VIP影视解析平台" />
<link href="./images/admin.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" type="image/x-icon" href="./../favicon.ico"><?php 