﻿document.getElementById("show").style.display = "block";
document.getElementById("show").onclick=function() {document.getElementById("show").style.display = "none";};